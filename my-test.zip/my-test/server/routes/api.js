var express = require ('express');
var bodyParser = require ('body-parser');
var mongoConnectionString = 'mongodb://localhost:27017/My_test';

const mongoose = require ('mongoose');
mongoose.connect (mongoConnectionString, {useUnifiedTopology: true});
var db = mongoose.connection;
db.on ('error', console.log.bind (console, 'connection error'));
db.once ('open', function (callback) {
  console.log ('connection succeeded');
});
var app = express ();

app.use (bodyParser.json ());
app.use (express.static ('public'));
app.use (
  bodyParser.urlencoded ({
    extended: true,
  })
);

app.post ('/register', function (req, res) {
  var data = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    username: req.body.username,
    password: req.body.password,
    email: req.body.email,
    mobile: req.body.mobile,
    city: req.body.city,
    country: req.body.country,
    confirmpassword: req.body.confirmpassword,
    gender: req.body.gender,
    addressline: req.body.addressline,
    state: req.body.state,
    dob: req.body.dob,
    roles: req.body.roles,
    addressline2: req.body.addressline2,
    pincode: req.body.pincode,
  };
  db.collection ('details').insertOne (data, function (err, result) {
    if (err) throw err;
    console.log ('Record inserted Successfully');
    console.log (data.username);
    return res.send (data);
  });
});
app.post ('/login', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  console.log (username + password);
  db
    .collection ('details')
    .find ({username: username, password: password})
    .toArray (function (err, result) {
      console.log (result);
      if (err || result.length <= 0) {
        res.status (400).json ();
        console.log ('invalid user');
      } else {
        res.send (result);
        console.log ('successful login');
      }
    });
});

app.get ('/data', function (req, res) {
  var username = req.body.username;
  var password = req.body.password;
  db.collection ('details').find ({}).toArray (function (err, result) {
    console.log (result);
    if (err) throw err;
    console.log (result);
    res.send (result);
  });
});

app.delete('/data/:firstName', function (req, res) {
    var firstName = req.params.firstName;
  console.log ('firstName is' + req.params.firstName);
  console.log ('param is' + firstName);
  db.collection ('details')
    .deleteMany ({firstName: firstName}, function (err, result) {
      if (err) throw err;
      console.log ('result is' + result);
      db.collection ('details').find ({firstName}).toArray(function (err, data) {
        if (err) throw err;
        console.log ('mongo connected');
        // console.log (data);
        res.send (result);
      });
    });
});

app.put ('/data/:firstname', function (req, res) {
  console.log ('_id in api to update is' + req.params.firstname);
  console.log ('_id in api to update is' + req.body.email);
  console.log ('_id in api to update is' + req.body.username);
  console.log ('_id in api to update is' + req.body.mobile);
  console.log ('_id in api to update is' + req.body.roles);
  console.log ('_id in api to update is' + req.body.gender);

  console.log ('connected to db successfully to save update');
  var id = new mongoose.Types.ObjectId (req.params.name);
  console.log (id);
  db.collection ('datasaf').find (id).toArray (function (err, data) {
    if (err) throw err;
    console.log (data);
    db.collection ('datasaf').updateMany (
      {_id: id},
      {
        $set: {
          firstname: req.body.firstname,
          email: req.body.email,
          username: req.body.username,
          mobile: req.body.mobile,
          roles: req.body.roles,
          gender: req.body.gender,
        },
      }
    );
    res.send (data);
  });
});

module.exports = app;
