import { Component, OnInit } from '@angular/core';
import { LoginService } from "../services/login.service";
import{Http, Response, Headers, RequestOptions} from '@angular/http';



@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {

  test: any[];
  datatobeedited:any;
  update:boolean=false;
  chname:string;
  chage:string;

  constructor(private http:LoginService, private _http:Http) { }

  ngOnInit() {
    this.http.getData().subscribe((res:any) =>{
      this.test=res;
      console.log(res);
    })
  }

  deleteData(firstname:any,x:any) {
    console.log(firstname);
    this.http.deleteData().subscribe((res:any)=>{
      console.log(res);
    })
  }
  editData(i:any) {  
    this.update=true;
    this.datatobeedited=i;
    console.log("obj is"+this.datatobeedited.firstname);
  }
  saveUpdate(datatobesaved:any)
  {    
    let _url="http://localhost:3000/api/data"+"/"+datatobesaved._id;
  
    var headers= new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers }); 
    this._http.put(_url,datatobesaved, options)
          .subscribe(data => {
                alert('saved Successfully');
          }, error => {
              console.log(JSON.stringify(error.json()));
          })
 
  }

}
