import { Injectable } from '@angular/core';
import { HttpService } from "../http.service";


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  firstName:any;
  private readonly userdata = 'api/data';
  private readonly delete = 'api/data';


  constructor(private http:HttpService) { }

  getData() {
    return this.http.get(this.userdata);
  }
  deleteData(){
  return this.http.delete(this.delete +"/"+this.firstName)
  }
}
