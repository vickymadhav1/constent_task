import { Component, OnInit } from '@angular/core';
// import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { RegisterService } from "../services/register.service";

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {

  Gender: any = ['male', 'female'];
  Roles: any = ['UI', 'MEAN STACK', 'FULL STACK'];

  registerForm: FormGroup;
  loading = false;
  submitted = false;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: RegisterService,
  ) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', Validators.required],
      mobile: ['', Validators.required],
      city: ['', Validators.required],
      country: ['', Validators.required],
      confirmpassword: ['', Validators.required],
      gender: ['', Validators.required],
      addressline: ['', Validators.required],
      state: ['', Validators.required],
      dob: ['', Validators.required],
      roles: ['', Validators.required],
      addressline2: ['', Validators.required],
      pincode: ['', Validators.required],

    });
  }
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
    
    if (this.registerForm.invalid) {
      return;
    }
    this.loading = true;
    this.userService.register(this.registerForm.value)
      .pipe(first())
      .subscribe((res: any) => {
        console.log(res)
        this.router.navigate(['/login']);
      },
        error => {
          this.loading = false;
        });
  }
}
