import { Injectable } from '@angular/core';
import { HttpService } from "../http.service";


@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private readonly registerApi = 'api/register';

  constructor(private http:HttpService) { }


  register(user) {
    return this.http.post(this.registerApi, user);
  }
}
