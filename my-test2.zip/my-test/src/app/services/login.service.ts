import { Injectable } from '@angular/core';
import { HttpService } from "../http.service";


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  firstName:any;
  private readonly userdata = '/users';
  private readonly delete = '/users';


  constructor(private http:HttpService) { }

  getData(finaldata) {
    return this.http.post(this.userdata, finaldata);
  }
  deleteData(){
  return this.http.delete(this.delete +"/"+this.firstName)
  }
}
